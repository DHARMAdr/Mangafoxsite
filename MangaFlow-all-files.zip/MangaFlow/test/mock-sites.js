/* =====================================================================
   MangaFlow TEST helper - mock-sites.js   (only for testing, never part of the website)
   WHY: MangaFlow must be tested without touching real manga sites. This file starts three FAKE sites on your own PC:
        1. Site A  (port 9100, /manga/...)  a normal site: static chapter list, pictures in data-src (JPG, WebP, PNG mixed).
        2. Site B  (port 9100, /arena/...)  like many scanlation sites: the pictures exist ONLY inside a <script> list,
           and the picture host (port 9101) refuses requests that have no matching Referer (hotlink protection).
        3. Site C  (port 9100, /n/...)      chapter list whose links have no "chapter" word, only numbers.
        Also: /blocked answers 403 and /botcheck answers a "Just a moment..." page (to test the error pop-ups).
   HOW:  node test/mock-sites.js     (keep it running)   then   MF_ALLOW_PRIVATE=1 node proxy-local.js   then   node test/e2e-test.js
   IMPROVE: add a site that needs a POST for its chapter list, and one that sends 429 after 10 requests.
   ===================================================================== */
// Mock manga sites for testing MangaFlow. Original test data only.
const http = require('http'), fs = require('fs'), path = require('path');
const IMG = path.join(__dirname, 'img');
const N_A = 25, N_B = 12;
const page = (title, body) => `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title></head><body>${body}</body></html>`;
const pad = s => s + '<!-- ' + 'x'.repeat(260) + ' -->';
const SITE = 'http://127.0.0.1:9100';
let hotlinkRefusals = 0;

// Site A: classic site, static chapter list, images with data-src
function siteA(p) {
  if (p === '/') return page('Mock Home', pad('<h1>Mock Manga Home</h1><div class="latest">' +
    [1,2,3].map(i => `<a href="/manga/other-${i}/chapter-1/">Other ${i} Chapter 1</a>`).join('') + '</div>'));
  let m;
  if ((m = /^\/manga\/test-series\/?$/.exec(p))) {
    const li = Array.from({length: N_A}, (_, i) => N_A - i).map(n => `<li><a href="/manga/test-series/chapter-${n}/">Chapter ${n}</a></li>`).join('');
    return page('Test Series - Mock Manga', pad(`<h1>Test Series</h1><img src="/img/p1.jpg" width="200" height="300"><ul class="main">${li}</ul><div class="side"><a href="/manga/other-1/chapter-9/">Other 1 Chapter 9</a></div>`));
  }
  if ((m = /^\/manga\/test-series\/chapter-(\d+)\/?$/.exec(p))) {
    const n = +m[1];
    const imgs = [1,2,3,4].map(k => `<img class="wp-manga-chapter-img" data-src="${SITE}/img/c${n}-p${k}.${k === 3 ? 'webp' : k === 4 ? 'png' : 'jpg'}">`).join('');
    const next = n < N_A ? `<a rel="next" href="/manga/test-series/chapter-${n + 1}/">Next</a>` : '';
    return page(`Test Series Chapter ${n} - Mock Manga`, pad(`<h1>Test Series - Chapter ${n}</h1><div class="reading-content">${imgs}</div>${next}<a href="/manga/test-series/">Test Series</a>`));
  }
  return null;
}
// Site B: "script-hidden pictures + hotlink protection" (like many scanlation sites)
function siteB(p) {
  let m;
  if ((m = /^\/arena\/series\/arena-test\/?$/.exec(p))) {
    const li = Array.from({length: N_B}, (_, i) => N_B - i).map(n => `<li data-num="${n}"><a href="/arena/arena-test-chapter-${n}/"><span class="chapternum">Chapter ${n}</span></a></li>`).join('');
    return page('Arena Test - Mock Scans', pad(`<h1 class="entry-title">Arena Test</h1><div id="chapterlist"><ul class="clstyle">${li}</ul></div>`));
  }
  if ((m = /^\/arena\/arena-test-chapter-(\d+)\/?$/.exec(p))) {
    const n = +m[1];
    const imgs = [1,2,3,4,5].map(k => `${'http:\\/\\/127.0.0.1:9101\\/p\\/' + n + '\\/0' + k + '.jpg'}`);
    const data = '{"post_id":1,"sources":[{"source":"Server 1","images":[' + imgs.map(x => '"' + x + '"').join(',') + ']}],"lazyload":false}';
    return page(`Arena Test Chapter ${n} - Mock Scans`, pad(`<h1>Arena Test Chapter ${n}</h1><div id="readerarea"></div><script>ts_reader.run(${data});</script><a href="/arena/series/arena-test/">All chapters</a>`));
  }
  // numeric style site: list links have no "chapter" word in the address, text is only a number
  if ((m = /^\/n\/series\/numbered\/?$/.exec(p))) {
    const li = Array.from({length: 8}, (_, i) => 8 - i).map(n => `<li><a href="/n/read/${48000 + n}">${n}</a></li>`).join('');
    return page('Numbered Test - Mock', pad(`<h1>Numbered Test</h1><div class="chapter-list"><ul>${li}</ul></div>`));
  }
  if ((m = /^\/n\/read\/(\d+)$/.exec(p))) {
    const n = +m[1] - 48000;
    const imgs = [1,2,3].map(k => `<img src="${SITE}/img/n${n}-p${k}.jpg">`).join('');
    return page(`Numbered Test ${n}`, pad(`<h1>Numbered Test</h1><div class="reader">${imgs}</div>`));
  }
  return null;
}

// Site D (round 9): like en-thunderscans.com. Chapters live at the ROOT (/ts/grimoire-chapter-N/), the series page is
// /ts/comics/grimoire/ (NOT a path prefix of the chapter address), the prev/next buttons are "#/prev/" placeholders and the
// real addresses are only inside the ts_reader JSON ("prevUrl" / "nextUrl"). No chapter dropdown on the chapter page.
const N_D = 8;
function siteD(p) {
  let m;
  if ((m = /^\/ts\/comics\/grimoire\/?$/.exec(p))) {
    const li = Array.from({length: N_D}, (_, i) => N_D - i).map(n => `<li><a href="/ts/grimoire-chapter-${n}/"><span class="chapternum">Chapter ${n}</span></a></li>`).join('');
    return page('Grimoire Wizard - Mock Thunder', pad(`<h1 class="entry-title">Grimoire Wizard</h1><div id="chapterlist"><ul>${li}</ul></div>`));
  }
  if ((m = /^\/ts\/grimoire-chapter-(\d+)\/?$/.exec(p))) {
    const n = +m[1]; if (n < 1 || n > N_D) return null;
    const imgs = [1,2,3,4].map(k => '"http:\\/\\/127.0.0.1:9100\\/img\\/c' + n + '-p' + k + '.jpg"').join(',');
    const prevUrl = n > 1 ? 'http:\\/\\/127.0.0.1:9100\\/ts\\/grimoire-chapter-' + (n - 1) + '\\/' : '';
    const nextUrl = n < N_D ? 'http:\\/\\/127.0.0.1:9100\\/ts\\/grimoire-chapter-' + (n + 1) + '\\/' : '';
    const data = '{"post_id":7,"prevUrl":"' + prevUrl + '","nextUrl":"' + nextUrl + '","sources":[{"source":"Server 1","images":[' + imgs + ']}]}';
    return page(`Grimoire Wizard Chapter ${n} - Mock Thunder`, pad(`<h1>Grimoire Wizard Chapter ${n}</h1><div class="allc"><a href="/ts/comics/grimoire/">Grimoire Wizard</a></div><div id="readerarea"></div><a class="ch-prev-btn" href="#/prev/">Prev</a><a class="ch-next-btn" href="#/next/">Next</a><script>ts_reader.run(${data});</script>`));
  }
  // a second site with NO series page at all: only the numbered chapter addresses exist (tests the "guess chapters 1..N" fallback)
  if ((m = /^\/ts2\/wiz-chapter-(\d+)\/?$/.exec(p))) {
    const n = +m[1]; if (n < 2 || n > 6) return null;                      // chapter 1 does NOT exist on purpose (a guessed chapter that must vanish quietly)
    const imgs = [1,2,3].map(k => `<img src="${SITE}/img/c${n}-p${k}.jpg">`).join('');
    return page(`Wiz Chapter ${n} - Mock`, pad(`<h1>Wiz Chapter ${n}</h1><div class="reader">${imgs}</div>`));
  }
  // a locked chapter: the page asks for a login (MangaFlow must say "LOCKED", not "broken")
  if (/^\/ts3\/locked-chapter-1\/?$/.test(p)) return page('Locked Chapter 1', pad('<h1>Locked Chapter 1</h1><p>This chapter is locked. Please log in to read.</p>'));
  return null;
}

// Site E (round 10): like roliascan.com. The chapter page has NO pictures (a script would add them); only the og:image meta tag
// points to page 1 ("/store/chapters/<code>/001.jpg"). The other pages are the next numbers; 006 and up do not exist.
function siteE(p) {
  let m;
  if ((m = /^\/rl\/read\/veteran\/?$/.exec(p))) {
    const li = Array.from({length: 6}, (_, i) => 6 - i).map(n => `<li><a href="/rl/read/veteran/chapter-${n}/">Chapter ${n}</a></li>`).join('');
    return page('Veteran - Mock Rolia', pad(`<h1>Veteran</h1><ul class="main">${li}</ul>`));
  }
  if ((m = /^\/rl\/read\/veteran\/chapter-(\d+)\/?$/.exec(p))) {
    const n = +m[1]; if (n < 1 || n > 6) return null;
    return `<!doctype html><html><head><meta charset="utf-8"><title>Chapter ${n} - Veteran | Read Manhwa Online</title><meta property="og:image" content="${SITE}/store/chapters/c${n}/001.jpg"></head><body>${pad(`<h1>Chapter ${n}</h1><div id="reader">Loading chapter...</div><img src="/logo.png"><img src="/logo2.png"><img src="/logo3.png"><a href="/rl/read/veteran/chapter-${n + 1}/">Next</a>`)}</body></html>`;
  }
  return null;
}
const mockSite = http.createServer((req, res) => {
  const u = new URL(req.url, SITE), p = u.pathname;
  if (p === '/blocked') { res.writeHead(403, {'content-type':'text/html'}); return res.end('<html><body>Forbidden</body></html>'); }
  if (p === '/botcheck') { res.writeHead(200, {'content-type':'text/html'}); return res.end(pad('<html><head><title>Just a moment...</title></head><body><div id="challenge-platform">Checking your browser</div></body></html>')); }
  let html = siteA(p) || siteB(p) || siteD(p) || siteE(p);
  const im = /^\/img\/(?:c\d+-|n\d+-)?p(\d)\.(jpg|png|webp)$/.exec(p);
  if (im) { const f = path.join(IMG, 'p' + im[1] + '.' + im[2]); res.writeHead(200, {'content-type': {jpg:'image/jpeg',png:'image/png',webp:'image/webp'}[im[2]]}); return res.end(fs.readFileSync(f)); }
  // pictures named like /img/c7-p3.webp and /img/n3-p2.jpg
  const im2 = /^\/img\/(?:c|n)\d+-p(\d)\.(jpg|png|webp)$/.exec(p);
  if (im2) { const f = path.join(IMG, 'p' + im2[1] + '.' + im2[2]); res.writeHead(200, {'content-type': {jpg:'image/jpeg',png:'image/png',webp:'image/webp'}[im2[2]]}); return res.end(fs.readFileSync(f)); }
  // numbered pictures for site E: /store/chapters/c3/001.jpg ... 005.jpg exist, 006 and higher do not
  const st = /^\/store\/chapters\/c\d+\/(\d{3})\.jpg$/.exec(p);
  if (st && !html) { const k = +st[1]; if (k >= 1 && k <= 5) { res.writeHead(200, {'content-type':'image/jpeg'}); return res.end(fs.readFileSync(path.join(IMG, 'p' + ((k - 1) % 4 + 1) + '.jpg'))); } res.writeHead(404); return res.end('no'); }
  if (!html) { res.writeHead(404, {'content-type':'text/html'}); return res.end(page('Not found', pad('404'))); }
  res.writeHead(200, {'content-type':'text/html; charset=utf-8'}); res.end(html);
}).listen(9100, '127.0.0.1');

// picture host with hotlink protection: only answers when the Referer is the mock site's arena pages
const imgHost = http.createServer((req, res) => {
  if (req.url === '/_stats') { res.writeHead(200); return res.end(JSON.stringify({ hotlinkRefusals })); }
  const ref = req.headers.referer || '';
  const m = /^\/p\/(\d+)\/0(\d)\.jpg$/.exec(req.url);
  if (!m) { res.writeHead(404); return res.end('no'); }
  if (!ref.startsWith(SITE + '/arena/')) { hotlinkRefusals++; res.writeHead(403); return res.end('hotlink'); }
  res.writeHead(200, {'content-type':'image/jpeg'});     // note: NO CORS header on purpose
  res.end(fs.readFileSync(path.join(IMG, 'p' + (((+m[2]) - 1) % 4 + 1) + '.jpg')));
}).listen(9101, '127.0.0.1');
console.log('mock sites on 9100 / 9101');
