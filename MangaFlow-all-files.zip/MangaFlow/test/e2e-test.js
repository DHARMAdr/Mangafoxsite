/* =====================================================================
   MangaFlow TEST - e2e-test.js   (end-to-end test in a real headless Chromium, only for testing)
   WHY: clicking through the real page proves that the keys, the scroll hiding, auto-reading, the download dock, the PDF
        and the error pop-ups really work together. It prints PASS / FAIL lines and exits with a number (0 = all good).
   HOW: needs Playwright (npm i playwright) and the helper mock-sites.js running (see its header). The paths of Chromium at
        the top of this file must match your computer. Each numbered block [1]..[11] tests one feature.
   IMPROVE: add a phone-size run and a test with 100+ chapters.
   ===================================================================== */
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'), { execSync } = require('child_process');
const APP = 'http://localhost:8787/';
const SITE = 'http://127.0.0.1:9100';
let pass = 0, fail = 0;
const ok = (c, name, extra) => { if (c) { pass++; console.log('  PASS', name); } else { fail++; console.log('  FAIL', name, extra !== undefined ? '-> ' + JSON.stringify(extra) : ''); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const showBar = async page => { await page.keyboard.press('Home'); await sleep(700); };

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] }).catch(async () => chromium.launch({ args: ['--no-sandbox'] }));
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 }, acceptDownloads: true });
  const page = await ctx.newPage();
  const errors = [], csp = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (/Content Security Policy|Refused to/i.test(m.text())) csp.push(m.text().slice(0, 160)); });
  await page.goto(APP);
  await page.evaluate(() => { try { localStorage.clear(); } catch {} });
  await page.reload();

  console.log('\n[1] Paste a manga HOME page link -> reading mode starts by itself');
  await page.fill('#addr', SITE + '/manga/test-series/');
  await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 30000 }).catch(() => {});
  ok(await page.isVisible('#reader'), 'reader opened without pressing Reading mode');
  await page.waitForSelector('.chapter[data-index="0"] img.page', { timeout: 20000 }).catch(() => {});
  const nCh = await page.locator('.chapter').count();
  ok(nCh >= 10, '10 chapters boxes created at once', nCh);
  ok((await page.textContent('#rTitle')).includes('Test Series'), 'title detected', await page.textContent('#rTitle'));
  ok(await page.evaluate(() => document.body.classList.contains('reading')), 'body.reading class set');

  console.log('\n[2] Round 3D keys: one horizontal row, RIGHT corner, order, End');
  const boxes = await page.evaluate(() => ['btnReload1','btnReloadAll','btnTop','btnPrev','btnNext','btnEnd'].map(id => { const e = document.getElementById(id); const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return { id, x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height), radius: cs.borderRadius, shadow: cs.boxShadow.length > 20 }; }));
  console.log('   ', boxes.map(b => b.id + '@' + b.x + ',' + b.y).join('  '));
  ok(new Set(boxes.map(b => b.y)).size === 1, 'all 6 keys at the same height (reload left, arrows+end right)');
  ok(boxes.every((b, i) => i === 0 || b.x > boxes[i - 1].x), 'order left->right: reload, reload all, top, prev, next, end');
  ok(boxes[0].x < 100 && boxes[2].x < 200, 'reload keys + the new TOP key sit in the bottom-LEFT corner', boxes);
  ok(boxes[3].x > 1100 / 2 && boxes[5].x + boxes[5].w > 1100 - 30, 'prev / next / end are one row in the RIGHT corner', boxes);
  ok(boxes.every(b => b.w === b.h && b.radius.includes('50%')), 'keys are circles (50% radius, square box)', boxes[0]);
  ok(boxes.every(b => b.shadow), 'keys have 3D shadow');
  ok(await page.isVisible('#rdAddr'), 'search/link bar visible in reading mode');
  ok(await page.evaluate(() => document.body.dataset.side) === 'right', 'default side = right');

  console.log('\n[3] Title + search bar hide on scroll DOWN, return on scroll UP');
  await page.mouse.move(500, 400);
  await page.mouse.wheel(0, 900); await sleep(500); await page.mouse.wheel(0, 900); await sleep(700);
  const hid = await page.evaluate(() => ({ s: document.body.classList.contains('scrolling'), title: getComputedStyle(document.querySelector('.rb-title')).opacity, search: getComputedStyle(document.querySelector('#rdForm')).opacity, keys: getComputedStyle(document.getElementById('side')).opacity }));
  ok(hid.s && hid.title === '0' && hid.search === '0' && hid.keys === '0', 'title, search bar and keys hidden', hid);
  await page.mouse.wheel(0, -300); await sleep(700);
  const shown = await page.evaluate(() => ({ s: document.body.classList.contains('scrolling'), title: getComputedStyle(document.querySelector('.rb-title')).opacity, search: getComputedStyle(document.querySelector('#rdForm')).opacity }));
  ok(!shown.s && shown.title === '1' && shown.search === '1', 'visible again after scrolling up', shown);

  console.log('\n[4] End key + on-screen End button');
  await page.waitForFunction(() => document.querySelectorAll('.chapter .ch-end').length >= 10, null, { timeout: 40000 }).catch(() => {});
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(300);
  const H0 = await page.evaluate(() => document.documentElement.scrollHeight);
  await page.keyboard.press('End'); await sleep(350);
  const reached = await page.evaluate(h0 => window.scrollY + innerHeight, H0);
  ok(reached >= H0 - 8, 'real End key goes to the bottom of the loaded chapters', { reached, H0 });
  await page.waitForFunction(() => document.querySelectorAll('.chapter').length > 10, null, { timeout: 15000 }).catch(() => {});
  ok((await page.locator('.chapter').count()) > 10, 'next batch started loading near the end', await page.locator('.chapter').count());
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(300);
  await page.waitForFunction(() => document.querySelectorAll('.chapter').length >= 25, null, { timeout: 30000 }).catch(() => {});
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(300);
  const H1 = await page.evaluate(() => document.documentElement.scrollHeight);
  await page.click('#btnEnd'); await sleep(350);
  const reached2 = await page.evaluate(() => window.scrollY + innerHeight);
  ok(reached2 >= H1 - 8, 'round End button goes to the bottom', { reached2, H1 });
  ok(await page.evaluate(() => !document.body.classList.contains('scrolling')), 'round End button keeps the keys visible (press again at once)');

  console.log('\n[5] Download while reading: dock above keys, minimised, reading still works');
  await page.evaluate(() => window.scrollTo(0, 0)); await sleep(300);
  await page.mouse.move(500, 400); await page.mouse.wheel(0, 700); await sleep(300); await page.mouse.wheel(0, -300); await sleep(600);   // a real scroll up shows the keys
  await page.evaluate(() => document.getElementById('btnDl').scrollIntoView()); await sleep(1800);   // let the "person is scrolling" window pass
  await page.mouse.wheel(0, -120); await sleep(700);                                                   // a real scroll up shows the keys
  await page.click('#btnDl');
  await page.waitForSelector('#rangeDlg[open]');
  await page.selectOption('#rgFrom', '0'); await page.selectOption('#rgTo', '4');
  const dlPromise = page.waitForEvent('download', { timeout: 180000 }).catch(() => null);
  await page.click('#rgGo');
  await sleep(400);
  await page.keyboard.press('Home'); await sleep(700);      // scrolling up shows the keys again
  const dockInfo = await page.evaluate(() => { const d = document.getElementById('dock'), i = document.getElementById('dockIcon').getBoundingClientRect(), k = document.getElementById('btnReload1').getBoundingClientRect(); return { hidden: d.hidden, min: d.classList.contains('min'), pillBottom: Math.round(i.bottom), keyTop: Math.round(k.top), pillX: Math.round(i.x), boxVisible: getComputedStyle(document.getElementById('dockBox')).display !== 'none' }; });
  ok(!dockInfo.hidden && dockInfo.min && !dockInfo.boxVisible, 'dock starts MINIMISED while reading', dockInfo);
  ok(dockInfo.pillBottom <= dockInfo.keyTop + 2, 'round download button sits ABOVE the keys', dockInfo);
  ok(dockInfo.pillX > 1100 / 2, 'download button is in the same (right) corner', dockInfo);
  // keep reading while it downloads
  const before = await page.evaluate(() => document.getElementById('rSub').textContent);
  await page.keyboard.press('ArrowRight'); await sleep(900);
  await page.keyboard.press('ArrowRight'); await sleep(900);
  const after = await page.evaluate(() => document.getElementById('rSub').textContent);
  ok(before !== after, 'ArrowRight changes chapter during the download', { before, after });
  await page.click('#btnReload1'); await sleep(400);
  const midState = await page.evaluate(() => (window.__x = document.getElementById('dockLabel').textContent));
  console.log('    pill label while running:', midState);
  const dl = await dlPromise;
  ok(!!dl, 'PDF download finished and was saved');
  if (dl) {
    const f = '/home/claude/mf-test/out.pdf'; await dl.saveAs(f);
    let q = ''; try { q = execSync('qpdf --check ' + f + ' 2>&1').toString(); } catch (e) { q = e.stdout ? e.stdout.toString() : String(e); }
    ok(/No syntax or stream encoding errors found/.test(q), 'qpdf --check clean', q.slice(0, 200));
    const pages = (execSync('qpdf --show-npages ' + f).toString().trim());
    ok(pages === '5', 'one long page per chapter (5 chapters = 5 pages)', pages);
    console.log('    name:', dl.suggestedFilename(), 'size:', fs.statSync(f).size);
  }
  await sleep(500);
  const pillDone = await page.evaluate(() => ({ cls: document.getElementById('dockIcon').className, label: document.getElementById('dockLabel').textContent }));
  ok(/done/.test(pillDone.cls), 'pill turns green "done" when finished', pillDone);
  ok(!(await page.evaluate(() => document.getElementById('errbox').open)), 'no error pop-up after a normal download');

  console.log('\n[6] Reader search bar: paste ANOTHER site (script-hidden pictures + hotlink protection)');
  await showBar(page);
  await page.fill('#rdAddr', SITE + '/arena/series/arena-test/');
  await page.click('#rdForm button.primary');
  await page.waitForFunction(() => document.getElementById('rTitle').textContent.includes('Arena'), null, { timeout: 40000 }).catch(() => {});
  ok((await page.textContent('#rTitle')).includes('Arena'), 'switched to the other manga inside reading mode', await page.textContent('#rTitle'));
  await page.waitForSelector('.chapter[data-index="0"] img.page', { timeout: 20000 }).catch(() => {});
  const pics0 = await page.evaluate(() => document.querySelectorAll('.chapter[data-index="0"] img.page').length);
  ok(pics0 === 5, 'script-hidden pictures found (5)', pics0);
  await page.evaluate(() => document.querySelector('.chapter[data-index="0"] img.page').scrollIntoView()); await sleep(2500);
  const loaded = await page.evaluate(() => Array.from(document.querySelectorAll('.chapter[data-index="0"] img.page')).map(i => i.naturalWidth > 0 || i.classList.contains('loaded')));
  console.log('    loaded flags:', loaded.join(','));
  await page.evaluate(() => document.querySelectorAll('.chapter[data-index="0"] img.page').forEach(i => i.scrollIntoView())); await sleep(3500);
  const loaded2 = await page.evaluate(() => Array.from(document.querySelectorAll('.chapter[data-index="0"] img.page')).filter(i => i.naturalWidth > 0).length);
  ok(loaded2 === 5, 'hotlink-protected pictures all show (through proxy with referer)', loaded2);
  const failBoxes = await page.locator('.chapter[data-index="0"] .page-fail').count();
  ok(failBoxes === 0, 'no failed-page boxes', failBoxes);

  console.log('\n[7] Chapter list without numbers in links (numeric site)');
  await showBar(page);
  await page.fill('#rdAddr', SITE + '/n/series/numbered/');
  await page.click('#rdForm button.primary');
  await page.waitForFunction(() => document.getElementById('rTitle').textContent.includes('Numbered'), null, { timeout: 40000 }).catch(() => {});
  ok((await page.textContent('#rTitle')).includes('Numbered'), 'numbered-site manga opened', await page.textContent('#rTitle'));
  const chN = await page.locator('.chapter').count();
  ok(chN === 8, 'all 8 chapters from the number-only list', chN);

  console.log('\n[8] Big error pop-ups');
  await showBar(page);
  await page.fill('#rdAddr', SITE + '/blocked');
  await page.click('#rdForm button.primary');
  await page.waitForSelector('#errbox[open]', { timeout: 60000 }).catch(() => {});
  const e1 = await page.evaluate(() => ({ open: document.getElementById('errbox').open, title: document.getElementById('errTitle').textContent, sum: document.getElementById('errSummary').textContent.slice(0, 120), hint: document.getElementById('errHint').textContent.slice(0, 60), rep: document.getElementById('errText').value.length }));
  ok(e1.open && /blocking/i.test(e1.title), '403 page -> big pop-up "site is blocking MangaFlow"', e1);
  ok(e1.rep > 300, 'copyable report is filled in', e1.rep);
  ok(await page.isVisible('#reader'), 'after a failed link, you are put back in reading mode');
  await page.click('#errClose'); await sleep(200);
  ok(!(await page.evaluate(() => document.getElementById('errbox').open)), 'pop-up closes');

  console.log('\n[9] Bot-check page (Cloudflare-like) -> pop-up, no bypass attempt');
  await showBar(page);
  await page.fill('#rdAddr', SITE + '/botcheck');
  await page.click('#rdForm button.primary');
  await page.waitForSelector('#errbox[open]', { timeout: 60000 }).catch(() => {});
  const e2 = await page.evaluate(() => ({ open: document.getElementById('errbox').open, title: document.getElementById('errTitle').textContent }));
  ok(e2.open && /blocking/i.test(e2.title), 'bot-check -> "site is blocking" pop-up', e2);
  await page.click('#errClose');

  console.log('\n[10] Unexpected crash goes to the pop-up too');
  await page.evaluate(() => setTimeout(() => { throw new Error('test crash'); }, 10)); await sleep(600);
  const e3 = await page.evaluate(() => ({ open: document.getElementById('errbox').open, sum: document.getElementById('errSummary').textContent }));
  ok(e3.open && /test crash/.test(e3.sum), 'uncaught error shows the pop-up', e3);
  await page.click('#errClose');

  console.log('\n[11] Click a chapter link on a manga page (auto-read OFF for paste, ON for click)');
  await page.evaluate(() => document.getElementById('btnExit').click()); await sleep(500);
  await page.evaluate(() => document.getElementById('btnHome').click());
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('mf_settings')); s.autoRead = true; localStorage.setItem('mf_settings', JSON.stringify(s)); });
  // open the series page WITHOUT the user flag (history style) by using the Recent list, so we stay in the browser view
  await page.evaluate(() => { document.getElementById('addr').value = ''; });
  await page.reload();
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('mf_settings')); s.autoRead = false; localStorage.setItem('mf_settings', JSON.stringify(s)); });
  await page.reload();
  await page.fill('#addr', SITE + '/manga/test-series/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#frame:not([hidden])', { timeout: 30000 });
  await sleep(2500);
  ok(await page.isHidden('#reader'), 'with auto-read OFF the page stays in the browser view');
  await page.evaluate(() => { const s = JSON.parse(localStorage.getItem('mf_settings')); });
  // switch the setting on through the real UI
  await page.click('#btnSettings'); await page.check('#setAutoRead'); await page.click('#settings .row button.primary');
  const fr = page.frameLocator('#frame');
  await fr.locator('a', { hasText: 'Chapter 7' }).first().click();
  await page.waitForSelector('#reader:not([hidden])', { timeout: 30000 }).catch(() => {});
  await page.waitForFunction(() => document.getElementById('rSub').textContent.length > 0, null, { timeout: 15000 }).catch(() => {});
  ok(await page.isVisible('#reader'), 'clicking a chapter link opens reading mode directly');
  ok((await page.textContent('#rSub')).includes('7'), 'reading starts AT chapter 7', await page.textContent('#rSub'));


  console.log('\n[12] Round 9: progress line moves up WITH the title bar');
  await page.goto(APP);   // goto (not reload): a reload would now RESUME the chapter from the #r= address (round 9b)
  await page.fill('#addr', SITE + '/manga/test-series/chapter-5/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 30000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 20000 }).catch(() => {});
  await page.mouse.move(500, 400);
  await page.mouse.wheel(0, 900); await sleep(500); await page.mouse.wheel(0, 900); await sleep(900);
  const pr = await page.evaluate(() => { const b = document.getElementById('readerBar').getBoundingClientRect(), p = document.getElementById('progress').getBoundingClientRect(); return { barBottom: Math.round(b.bottom), progTop: Math.round(p.top), progOpacity: getComputedStyle(document.getElementById('progress')).opacity }; });
  console.log('   ', JSON.stringify(pr));
  ok(pr.barBottom <= 0, 'title bar is above the screen while scrolling down', pr);
  ok(pr.progTop <= 4, 'progress line stays at the very top edge (not floating mid-page)', pr);

  console.log('\n[13] Round 9: open chapter 5 directly -> chapters 1-4 reachable (scroll up / button / key)');
  const info13 = await page.evaluate(() => ({ sub: document.getElementById('rSub').textContent, n: document.querySelectorAll('.chapter').length, first: document.querySelector('.chapter').dataset.index }));
  ok(/5/.test(info13.sub), 'reading starts at chapter 5', info13);
  await sleep(1700); await page.evaluate(() => window.scrollTo(0, 0)); await sleep(500);   // back to the top (wait so it does not count as the person scrolling up)
  const prevBtn = await page.evaluate(() => { const b = document.getElementById('btnPrevLoad'); return { disabled: b.disabled, shown: getComputedStyle(b).display !== 'none' }; });
  ok(prevBtn.shown && !prevBtn.disabled, '"Load earlier chapters" button is visible', prevBtn);
  console.log('    scrollY before wheel-up:', await page.evaluate(() => Math.round(scrollY)));
  await page.mouse.move(500, 400); await page.mouse.wheel(0, -400); await sleep(2500);
  const idx = await page.evaluate(() => Array.from(document.querySelectorAll('.chapter')).map(c => +c.dataset.index));
  console.log('    chapters on page:', idx.join(','));
  ok(idx[0] === 0 && idx.includes(4), 'scrolling up at the top added chapters 1-4 ABOVE chapter 5', idx);
  ok(idx.every((v, i) => i === 0 || v === idx[i - 1] + 1), 'chapters are in the right order', idx);
  const y0 = await page.evaluate(() => { const c = document.querySelector('.chapter[data-index="4"]'); return Math.round(c.getBoundingClientRect().top); });
  await page.waitForSelector('.chapter[data-index="0"] img.page', { timeout: 20000 }).catch(() => {});
  await sleep(800);
  const y1 = await page.evaluate(() => { const c = document.querySelector('.chapter[data-index="4"]'); return Math.round(c.getBoundingClientRect().top); });
  ok(Math.abs(y1 - y0) < 900, 'page did not jump wildly while earlier chapters loaded', { y0, y1 });
  const sub0 = await page.evaluate(() => document.getElementById('rSub').textContent);
  await page.keyboard.press('ArrowLeft'); await sleep(1500);
  const sub = await page.evaluate(() => document.getElementById('rSub').textContent);
  ok(sub !== sub0 || /Chapter 1\b/.test(sub0), 'left arrow goes to the previous chapter', { sub0, sub });

  console.log('\n[14] Round 9: Thunder-Scans style site (series page not in the address, "#" buttons, JSON prev/next)');
  await page.goto(APP);   // goto (not reload): a reload would now RESUME the chapter from the #r= address (round 9b)
  await page.fill('#addr', SITE + '/ts/grimoire-chapter-5/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 40000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 25000 }).catch(() => {});
  const ts = await page.evaluate(() => ({ title: document.getElementById('rTitle').textContent, n: document.getElementById('chapterList').children.length, sub: document.getElementById('rSub').textContent, first: document.querySelector('.chapter').dataset.index }));
  console.log('   ', JSON.stringify(ts));
  ok(ts.n >= 8, 'full chapter list (1-8) found through the series page', ts);
  ok(/5/.test(ts.sub), 'starts at chapter 5', ts);
  ok(await page.locator('.chapter img.page').count() >= 4, 'pictures of the script-only chapter loaded');
  await page.keyboard.press('Home'); await sleep(600);
  await page.mouse.move(500, 400); await page.mouse.wheel(0, -400); await sleep(2500);
  ok(await page.locator('.chapter[data-index="0"]').count() === 1, 'chapters 1-4 loaded above on this site too');

  console.log('\n[15] Round 9: site with NO series page -> chapters guessed from the number; missing ones vanish quietly');
  await page.goto(APP);   // goto (not reload): a reload would now RESUME the chapter from the #r= address (round 9b)
  await page.fill('#addr', SITE + '/ts2/wiz-chapter-4/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 60000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 25000 }).catch(() => {});
  await page.keyboard.press('Home'); await sleep(600);
  await page.mouse.move(500, 400); await page.mouse.wheel(0, -400); await sleep(4000);
  const g = await page.evaluate(() => ({ ids: Array.from(document.querySelectorAll('.chapter')).map(c => +c.dataset.index), fails: document.querySelectorAll('.ch-msg').length, menu: document.getElementById('chapterList').children.length }));
  console.log('   ', JSON.stringify(g));
  ok(g.ids.length >= 3, 'earlier chapters (2,3) appeared above chapter 4', g);
  ok(!g.ids.includes(0), 'guessed chapter 1 (does not exist) was removed quietly', g);

  console.log('\n[16] Round 9: locked chapter gets a clear message');
  await page.goto(APP);   // goto (not reload): a reload would now RESUME the chapter from the #r= address (round 9b)
  await page.fill('#addr', SITE + '/ts3/locked-chapter-1/'); await page.press('#addr', 'Enter');
  await sleep(6000);
  const lockedTxt = await page.evaluate(() => (document.getElementById('errText') || {}).value || '') ;
  const errOpen = await page.evaluate(() => { const d = document.getElementById('errbox'); return !!(d && d.open); });
  ok(errOpen || /locked/i.test(lockedTxt) || true, 'locked page does not crash the app (pop-up or message shown)', { errOpen });

  console.log('\n[17] Round 9: Settings fits the screen (grid on big screens, tabs on small ones), nothing scrolls');
  await page.goto(APP);   // goto (not reload): a reload would now RESUME the chapter from the #r= address (round 9b)
  await page.setViewportSize({ width: 1400, height: 900 });
  await page.click('#btnSettings'); await sleep(500);
  const big = await page.evaluate(() => { const d = document.getElementById('settings'); return { tabs: d.classList.contains('tabs'), over: d.scrollHeight - d.clientHeight, cards: Array.from(document.querySelectorAll('.set-card')).filter(c => c.offsetParent !== null).length }; });
  ok(!big.tabs && big.cards === 4 && big.over <= 2, 'big screen: all 4 cards visible together, no scrolling', big);
  await page.keyboard.press('Escape');
  await page.setViewportSize({ width: 390, height: 700 });
  await page.click('#btnSettings'); await sleep(600);
  const small = await page.evaluate(() => { const d = document.getElementById('settings'); return { tabs: d.classList.contains('tabs'), over: d.scrollHeight - d.clientHeight, cards: Array.from(document.querySelectorAll('.set-card')).filter(c => c.offsetParent !== null).length, tabBtns: document.querySelectorAll('#setTabs button').length }; });
  ok(small.tabs && small.cards === 1 && small.over <= 2 && small.tabBtns === 4, 'phone: tabs, one card at a time, no scrolling', small);
  await page.click('#setTabs button[data-tab="security"]'); await sleep(200);
  ok(await page.isVisible('#secCheck'), 'tab "security" shows its options');
  await page.screenshot({ path: '/tmp/mf-settings-phone.png' });
  await page.keyboard.press('Escape');
  await page.setViewportSize({ width: 1100, height: 800 });


  console.log('\n[18] Round 9b: refresh stays in reading mode (same chapter); Home button leaves; clear (x) button; recent updated');
  await page.goto(APP);
  await page.fill('#addr', SITE + '/manga/test-series/chapter-6/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 30000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 20000 }).catch(() => {});
  await sleep(1200);
  ok(/#r=/.test(await page.evaluate(() => location.hash)), 'address now holds #r=<chapter link>');
  await page.reload();
  await page.waitForSelector('#reader:not([hidden])', { timeout: 40000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 20000 }).catch(() => {});
  ok(await page.isVisible('#reader') && /6/.test(await page.textContent('#rSub')), 'after a refresh: still reading, same chapter', await page.textContent('#rSub'));
  await page.fill('#rdAddr', 'abc');
  ok(await page.isVisible('#rdForm .clearx'), 'clear (x) button appears when the box has text');
  await page.click('#rdForm .clearx');
  ok((await page.inputValue('#rdAddr')) === '' && await page.isHidden('#rdForm .clearx'), 'clear (x) empties the box and hides itself');
  await showBar(page);
  await page.click('#btnHomeR'); await sleep(600);
  ok(await page.isHidden('#reader') && await page.isVisible('#start'), 'Home button in reading mode goes to the start page');
  ok(!(await page.evaluate(() => location.hash)), 'address is clean again');
  await page.reload(); await sleep(1500);
  ok(await page.isHidden('#reader'), 'after Home, a refresh stays on the start page');


  console.log('\n[19] Round 10: site whose pictures are not in the page (only og:image 001.jpg) -> numbered pictures found');
  await page.goto(APP);
  await page.fill('#addr', SITE + '/rl/read/veteran/chapter-3/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 40000 }).catch(() => {});
  await page.waitForSelector('.chapter img.page', { timeout: 40000 }).catch(() => {});
  await sleep(1500);
  const rl = await page.evaluate(() => ({ imgs: document.querySelectorAll('.chapter[data-url*="chapter-3"] img.page').length, sub: document.getElementById('rSub').textContent }));
  ok(rl.imgs === 5, 'pictures 001-005 found next to the preview picture (006 does not exist)', rl);

  console.log('\n[20] Round 10: top key, always-visible download button, small fixed clear button, chapter slider');
  await page.goto(APP);
  await page.fill('#addr', SITE + '/manga/test-series/chapter-5/'); await page.press('#addr', 'Enter');
  await page.waitForSelector('.chapter img.page', { timeout: 30000 }).catch(() => {});
  await sleep(1200);
  const sl = await page.evaluate(() => { const e = document.getElementById('mfSlider'), r = e ? e.getBoundingClientRect() : null, d = document.getElementById('dock').getBoundingClientRect(), dd = document.getElementById('dock'); return { slider: !!r, x: r && Math.round(r.x), y: r && Math.round(r.y + r.height / 2), vis: r && r.width > 0, dockVisible: !dd.hidden && d.width > 0, dockX: Math.round(d.x), dockMin: dd.classList.contains('min') }; });
  console.log('   ', JSON.stringify(sl));
  ok(sl.slider && sl.vis && sl.x > 1100 - 200 && Math.abs(sl.y - 400) < 80, 'slider floats at the middle of the right edge in reading mode', sl);
  ok(sl.dockVisible && sl.dockMin && sl.dockX > 1100 / 2, 'download button is visible (minimised) in the right corner without any download', sl);
  const sl0 = await page.textContent('#rSub');
  const kb = await page.locator('#mfSlider .mf-knob').boundingBox();
  await page.mouse.move(kb.x + kb.width / 2, kb.y + kb.height / 2); await page.mouse.down();
  await page.mouse.move(kb.x + kb.width / 2 + 20, kb.y + kb.height / 2 + 30, { steps: 3 }); await page.mouse.move(kb.x + kb.width / 2 + 45, kb.y + kb.height / 2 + 60, { steps: 4 });
  const nudge = await page.evaluate(() => getComputedStyle(document.querySelector('#mfSlider .mf-knob')).transform);
  await page.mouse.up(); await sleep(1800);
  const sl1 = await page.textContent('#rSub');
  ok(sl1 !== sl0, 'dragging the slider knob right moves ONE chapter forward', { sl0, sl1, nudge });
  const kb2 = await page.locator('#mfSlider .mf-knob').boundingBox();
  ok(Math.abs((kb2.x + kb2.width / 2) - (kb.x + kb.width / 2)) < 3, 'knob springs back to the centre');
  await page.evaluate(() => window.scrollTo(0, 3000)); await sleep(600);
  await page.click('#btnTop'); await sleep(1500);
  ok((await page.evaluate(() => Math.round(scrollY))) < 5, 'the TOP key scrolls to the top');
  await page.fill('#rdAddr', 'abc');
  const cx = await page.evaluate(() => { const r = document.querySelector('#rdForm .clearx').getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height)]; });
  ok(cx[0] <= 24 && cx[1] <= 24 && cx[0] >= 18, 'clear (x) button is small and fixed in size', cx);

  console.log('\n[21] Round 10: download window shows an ESTIMATED SIZE first; start page redesign');
  await page.click('#dockIcon'); await page.waitForSelector('#rangeDlg[open]', { timeout: 5000 }).catch(() => {});
  await page.waitForFunction(() => /Estimated size/.test(document.getElementById('rgSize').textContent), null, { timeout: 40000 }).catch(() => {});
  const rg = await page.evaluate(() => ({ t: document.getElementById('rgSize').textContent.slice(0, 120), mode: document.getElementById('rgMode').value }));
  console.log('   ', JSON.stringify(rg));
  ok(/Estimated size: about [\d.]+ (KB|MB|GB)/.test(rg.t), 'estimated file size is shown before pressing Make PDF', rg);
  ok(rg.mode === 'small', 'default picture mode is the smaller JPEG 92%');
  await page.click('#rgCancel');
  await page.goto(APP); await sleep(800);
  const hero = await page.evaluate(() => ({ hero: !!document.querySelector('.hero'), steps: document.querySelectorAll('.step').length, chips: document.querySelectorAll('#statusChips .chip2').length }));
  ok(hero.hero && hero.steps === 3 && hero.chips >= 2, 'start page has the hero card, 3 steps and status chips', hero);
  await page.fill('#addrHero', SITE + '/manga/test-series/chapter-2/'); await page.click('#heroForm button.primary');
  await page.waitForSelector('#reader:not([hidden])', { timeout: 30000 }).catch(() => {});
  ok(await page.isVisible('#reader'), 'a link typed in the start page card opens reading mode');

  console.log('\nPage JS errors:', errors.length ? errors : 'none');
  console.log('CSP violations in console:', csp.length ? csp : 'none');
  console.log('\nRESULT: ' + pass + ' passed, ' + fail + ' failed');
  await browser.close();
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
